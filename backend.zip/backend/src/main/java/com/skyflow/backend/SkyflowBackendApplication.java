package com.skyflow.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyflowBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyflowBackendApplication.class, args);
	}

}
